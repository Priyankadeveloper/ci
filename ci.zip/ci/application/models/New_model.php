<?php

Class New_model extends CI_Model {


function hello()
{

	echo "done";



}}



?>