<?php 

Class Customer_model extends CI_Model {



        public function add_user($table,$data)
        {
               
                if($this->db->insert($table,$data)){

                $insert_id = $this->db->insert_id();

                return  $insert_id;

                }else{
                return 0;

                }

              
        }

        public function test(){
        	echo "Welcome customer";
        }

       

}