<?php 

Class User_model extends CI_Model {



        public function add_user($table,$data)
        {
         // $this->db->insert($table,$data);
               
           if($this->db->insert($table,$data)){

                $insert_id = $this->db->insert_id();

                return  $insert_id;

                }else{
                return 0;

                }

              
        }

public function login($data) {

$condition = "name =" . "'" . $data['username'] . "' AND " . "psw =" . "'" . $data['password'] . "'";
$this->db->select('*');
$this->db->from('user');
$this->db->where($condition);
$this->db->limit(1);
 $query = $this->db->get();

if ($query->num_rows() == 1) {
return true;
} else {
return false;
}
}
function Update($id,$data)
{

	$this->db->where("id",$id);
	$this->db->update("user",$data);
	
}


function show_user()
	{
		$this->db->order_by("id","DESC");
		$obj1=$this->db->get("user");
		return $obj1;
	}
	function delete_user($id)
	{
		$this->db->where("id",$id);
		$this->db->delete("user");
	}




	// Read data using username and password

// Read data from database to show data in admin page
public function read_user_information($username) {
	//print_r($username);
	//echo $destination_array = explode(',', $username);
//echo $x=$username.tostring();

$condition = "name =" . "'" . $username['username'] . "'";
$this->db->select('*');
$this->db->from('user');
$this->db->where($condition);
$this->db->limit(1);
 $query = $this->db->get();
 
if ($query->num_rows() == 1) {
return $query->result();
} else {
return false;
}
}

Public function get_data_by_id($table,$c_id,$id)
{
$query = $this->db->query('SELECT * FROM user WHERE id="$id"');
$res = $query->result();  // this returns an object of all results


} 
function show($id){
	  
	$this->db->where("id",$id);
	$obj=$this->db->get("user");
	return $obj;
	
	/*$query=$this->db->query("SELECT * FROM tbl_admin WHERE id='$id'");
		return $query;*/
		
		

	}

	/* add new */

	public function image($path,$post){ 
    $data = array( 
       /* 'naam' => $post['naam'], 
        'voornaam' => $post['voornaam'], 
        'text' => $post['text'], */
        'image'=>$path 
    ); 

    return $this->db->insert('user', $data); 
}

	/* add new*/	
	function update_p($id,$data)
	{
		$this->db->where("id",$id);
		$this->db->update("user",$data);
	}

       

}