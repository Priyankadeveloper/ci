<!DOCTYPE html>
<html>
<body>

<h2>HTML Forms</h2>

 <form id="add_form"  onsubmit="return add_form();" enctype="multipart/form-data">
  <div id="add_form_v"></div>
    First name:<br>
  <input type="text" name="f">
  <br>
  Last name:<br>
  <input type="text" name="l">
  <br><br>
  <input type="submit" value="Submit">
</form> 

<p>If you click the "Submit" button, the form-data will be sent to a page called "/action_page.php".</p>

</body>
</html>
<script type="text/javascript">

function add_form()
{
  
  $.ajax({
    type: 'POST',
    url : '<?php echo site_url();?>/Users/jsde',
    dataType : 'JSON',
    data : new FormData($('#add_form')[0]),
    contentType: false,
    cache: false,
    processData:false,
    success : function (resp) 
    {
    if (resp.status == 0) {   
      $('#add_form_v').html("<div class='alert alert-danger'>"+resp.msg+"</div>");
      } 
    else{
      
        // window.location.href= site_url+"admin/Admin_dasboard/console";
           location.reload();

    }
      
      
      
    } 
  });
  return false;
}
</script>