<html>

<head>
<title>Login Form</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css">
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'>
</head>
<body>

<?php
if (isset($message_display)) {
echo "<div class='message'>";
echo $message_display;
echo "</div>";
}
?>
<div id="main">
<div id="login">
<h2>Login Form</h2>
<hr/>
<?php //echo form_open('Users/list'); ?>
<?php 
      if(isset($errors)){
       	echo $errors;

       }
	 ?>
	 	<?php 
       if(isset($success)){
       	echo $success;

       }
       	 ?>
<form method="post" action="<?php echo site_url('Users/login_chk')?>/">
<?php
echo "<div class='error_msg'>";
if (isset($error_message)) {
echo $error_message;
}
echo validation_errors();
echo "</div>";
?>
<label>UserName :</label>
<input type="text" name="username" id="name" placeholder="username"/><br /><br />
<label>Password :</label>
<input type="password" name="password" id="password" placeholder="**********"/><br/><br />
<input type="submit" value=" Login " name="submit"/><br />

<?php //echo form_close(); ?>
</div>
</div>
</body>
</html>


<!--<!DOCTYPE html>
<html>
<head>
	<title>user list </title>
</head>
<body>
	<h1>Login</h1>

	<?php 
       if(isset($errors)){
       	echo $errors;

       }
	 ?>
	 	<?php 
       if(isset($success)){
       	echo $success;

       }
	 ?>
	<form action="" method="post">

		
		<label>User email</label>
		<input type="text" name="name">
		<br>
		<br>
		<label>Password</label>
		<input type="text" name="psw">
        <br>
		<br>
		<br>
<a href="<?php echo base_url() ?>index.php/user_authentication/user_registration_show">To SignUp Click Here</a>

		<input type="submit" name="add_login" value="Login">
	</form>

</body>
</html>-->
