<!DOCTYPE html>
<html>
<head>
	<title>user list </title>
</head>
<body>
	<h1>Registration</h1>
	<?php echo $this->session->flashdata("msg");?>

	<?php 
      if(isset($errors)){
       	echo $errors;

       }
	 ?>
	 	<?php 
       if(isset($success)){
       	echo $success;

       }
       	 ?>


	 <a href="<?php echo site_url('Users/login');?>">login</a>
 	 <a href="<?php echo site_url('Users/list');?>">Show List</a>
	<form action="" method="post" enctype="multipart/form-data">
	 <!--<form id="add_form"  onsubmit="return add_form();" enctype="multipart/form-data">-->
<div id="add_form_vß"></div>
		<label>User name</label>
		<input type="text" name="name"> 
		<br>
		<br>
		<label>User email</label>
		<input type="text" name="email">
		<br>
		<br>
		<label>Phone </label>
		<input type="number" name="phone">
        <br>
		<br>
		<br>
		<label>Address</label>
		<input type="text" name="address">
		<br>
		<br>
		<label>Password</label>
		<input type="password" name="password">
		<br>
		<br>
		<label>Confirm Password</label>
		<input type="password" name="confirm_p">
		<br/>
		<br/>
		<label for="Status">Image</label>
		<input type="file" class="form-control"  placeholder="Enter  Image" name="image">
		<!-- <button type="submit" class="btn btn-info">submit</button>
			-->		
		<input type="submit" name="add_user" value="Add User">
	</form>

</body>
</html>
 <!--<script type="text/javascript">

function add_form()
{
	
	$.ajax({
		type: 'POST',
		url : '<?php echo site_url();?>Users/index',
		dataType : 'JSON',
		data : new FormData($('#add_form')[0]),
		contentType: false,
		cache: false,
		processData:false,
		success : function (resp) 
		{
		if (resp.status == 0) {		
			$('#add_form_v').html("<div class='alert alert-danger'>"+resp.msg+"</div>");
  		} 
		else{
			
        // window.location.href= site_url+"admin/Admin_dasboard/console";
           location.reload();

		}
			
			
			
		}	
	});
	return false;
}
</script>-->