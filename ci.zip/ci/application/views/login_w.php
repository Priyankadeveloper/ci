<?php  if (isset($this->session->userdata['logged_in'])) {
echo $username; // print_r($data['rname']);
}?>
<a href="Users/logout">Logout</a>
<!--add new --->
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Striped Rows</h2>
  <p>The .table-striped class adds zebra-stripes to a table:</p>  

  <!-- <?php echo $this->session->flashdata("msg");?>-->
       
  <table class="table table-striped">
    <thead>
      <tr>
        <th>name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Address</th>
        <th>Image</th>
        <th>Delete</th>
        <th>Update</th>



      </tr>
    </thead>
    <tbody>
         <?php 

       foreach ($fetch_list->result_array() as $x)
   {  ?>
      <tr>

        <td><?php echo $x['name'];?></td>
        <td><?php echo $x['email'];?></td>
        <td><?php echo $x['phone'];?></td>
        <td><?php echo $x['address'];?>
        </td>
        <td><img width="50" height="50" src="<?php echo base_url().'/img/'.$x['image'];?>"></td>
        <td><a href="<?php echo site_url('Users/delete/').$x['id']?>/">Delete<a></td>
           <td><a href="<?php echo site_url('Users/Update/').$x['id']?>/">Update<a></td>
        <?php } ?>
      </tr>
      
    </tbody>
  </table>
</div>

</body>
</html>





<!--add new--->