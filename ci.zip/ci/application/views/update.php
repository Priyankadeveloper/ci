
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php echo $this->session->flashdata("msg");?>

<form action="<?php echo site_url("Users/profile_update")?>" method="post" enctype="multipart/form-data">

<?php
			$data=$user->row_array();

   //echo $data['id'];

   ?>
  <div class="form-group">
    <label for="email">Name:</label>
    <input type="text" class="form-control" name="name" value="<?php echo $data['name'];?>" >
  </div>
  <div class="form-group">
    <label for="pwd">email:</label>
    <input type="text" class="form-control" name="email" value="<?php echo $data['email'];?>">
  </div>
   <div class="form-group">
    <label for="pwd">Address:</label>
    <input type="text" class="form-control" name="ads" value="<?php echo $data['address'];?>">
  </div>
   <div class="form-group">
    <label for="pwd">phone:</label>
    <input type="text" class="form-control" name="phone" value="<?php echo $data['phone'];?>">
    <div>
<img width="50" height="50" src="<?php echo base_url().'/img/'.$data['image'];?>">
    </div>
  <input type="file" class="form-control" name="image" value="<?php echo $data['image'];?>">

    <input type="hidden" value="<?php echo $data['id'];?>" name="hid">
  </div>
  <?php //} ?>
  <button type="submit" class="btn btn-default">Submit</button>
</form>

</body>
</html>