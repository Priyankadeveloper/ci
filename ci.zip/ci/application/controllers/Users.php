<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {


	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
   	function __construct()
	{  
	    parent::__construct();
	     $this->load->helper(array('form', 'url'));

         $this->load->library('form_validation');
         $this->load->model('User_model');
         $this->load->model('Customer_model');
         $this->load->model('New_model');
          $this->load->library('session');
        
         	//	$this->backdoor();



       //  $this->New_model->hello();
       // $this->load->model('Admin_model');

        
	}
	/*--add new--*/
	function backdoor()
	{
		if (!$this->session->userdata('is_admin_login')) 
		{
			redirect("http://localhost/ci/index.php/Users/list");
		}
	}

		function add_form()
	{
		$this->form_validation->set_rules('name', ' Name', 'required');
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('phone', 'phone', 'required');
		$this->form_validation->set_rules('address', 'address', 'required');

		if ($this->form_validation->run() == FALSE)
		{
			$json['status'] = 0;
			$json['msg'] = validation_errors();
		}
		else
		{ 

			$config['upload_path']="img";
			$config['allowed_types'] = '*';
			$config['encrypt_name']=true;
			$this->load->library("upload",$config);

			$data['name']=$this->input->post("name");
			$data['email']=$this->input->post("email");
			$data['address']=$this->input->post("address");
			$data['phone']=$this->input->post("phone");

		
			//else
			//{
				if ($this->upload->do_upload('image'))
				{
					$data['image']=$this->upload->data("file_name");
				
					$run = $this->User_model->add_user
('user',$data);
					if($run)
					{
						$json['status'] = 1;
						$this->session->set_flashdata('msg',"<div class='alert alert-success'> successfully</div>");
					}
					else
					{
						$json['status'] = 0;
						$json['msg'] = 'Error: Please try again!';
					}
				}
				else
				{
					$json['status'] = 0;
					$json['msg'] = $this->upload->display_errors();
				}
			//}
		}	
		echo json_encode($json);		
				$this->load->view('user_list.php');
	
	}
	/*---add new--*/


	public function index()
	{
		



         $data=array();
		 if(isset($_POST['add_user'])){

		 	
		 	   $this->form_validation->set_rules('name', 'Username', 'required');
          
                $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
 $this->form_validation->set_rules('phone', 'Phone', 'required');
                $this->form_validation->set_rules('address', 'Address', 'required');
                $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]|alpha_numeric');
                $this->form_validation->set_rules('confirm_p', 'Confirm Password', 'required|matches[password]');



                if ($this->form_validation->run() == FALSE)
                {
                     $data['errors']=validation_errors();
                }
                else
                {
                	$data['name']=$this->input->post('name');
                   $data['email']=$this->input->post('email');
                   $data['phone']=$this->input->post('phone');
                   $data['address']=$this->input->post('address');
                    $data['psw']=$this->input->post('password');


                   $config['upload_path']="img";
			$config['allowed_types'] = '*';
			$config['encrypt_name']=true;
			$this->load->library("upload",$config);

            // $user_data=array('name'=>$name,'email'=>$email,'phone'=>$phone,'address'=>$adrs);

/* add new */

//if (
	$this->upload->do_upload('image');
//)
				//{
					$data['image']=$this->upload->data("file_name");
				
				       //     $user_data = array('img' => $this->upload->data());

//			$run = $this->User_model->image
//($this->upload->data("full_path"),$this->upload->data("file_name"));
					//if($run)
					//{
					//	$this->session->set_flashdata('msg',"<div class='alert alert-success'>Game has been added successfully</div>");
			              //	 $data['success']='User data successfully Added.';
				//  $this->load->view('user_list.php', $data);
               

				//}
				//	else
				//	{
/*$this->session->set_flashdata('msg',"<div class='alert alert-error'>Try again later</div>");	*/			
         //  $error = array('error' => $this->upload->display_errors());

//	}
			//	}
			//	else
			
			//	{
				 // $data['success']='User data successfully Added.';

					/*$json['status'] = 0;
					$json['msg'] = $this->upload->display_errors();
					*/
		//		}


/* add new */


                  $id=$this->User_model->add_user('user',$data);
                  if(isset($id) && $id!=''){
                  	 $data['success']='User data successfully Added.';

                  }else{
                  		 $data['errors']='User data  add Failed.';

                  }
                  
                }


		 }
		$this->load->view('user_list.php',$data);
	}
	/* add new */

	  public function create(){
    $this->load->helper('form');
    $this->load->library('form_validation');
    $data['title'] = 'Create a new Student';
    $this->form_validation->set_rules('naam', 'Naam', 'required');
    $this->form_validation->set_rules('voornaam', 'Voornaam', 'required');
    $this->form_validation->set_rules('text', 'Text', 'required');
    if ($this->form_validation->run() === FALSE){
        $this->load->view('templates/header', $data);
        $this->load->view('students/create');
        $this->load->view('templates/footer');
    }else{
        // Upload the files then pass data to your model
        $config['upload_path'] = '/uploads/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('userfile')){
            // If the upload fails
            echo $this->upload->display_errors('<p>', '</p>');
        }else{
            // Pass the full path and post data to the set_newstudent model
        $this->User_model->image($this->upload->data('full_path'),$this->input->post());
            $this->load->view('students/success');
        }
    }
}
	/*add new */

Public function login()
	{
		

         $data=array();
		 if(isset($_POST['add_login'])){

		 	
		 	   $this->form_validation->set_rules('name', 'Username', 'required');
          
                $this->form_validation->set_rules('psw', 'Password', 'required');
           

                if ($this->form_validation->run() == FALSE)
                {
                     $data['errors']=validation_errors();
                }
                else
                {


                	$name=$this->input->post('name');
                   $psw=$this->input->post('psw');
                 
                  $user_data=array('name'=>$name,'psw'=>$psw);

                  $id=$this->User_model->login($user_data);
                 if ($id == TRUE) {
                 	echo "login Done";

             }
             else{
                  		 $data['errors']='User data  add Failed.';


             }
                }
            }
		$this->load->view('login.php');



	}

/*function Update($id)
{
//echo $id;
 $this->load->

}*/
function login_chk()
{

$this->form_validation->set_rules('username', 'Username', 'required');
$this->form_validation->set_rules('password', 'Password', 'required');

if ($this->form_validation->run() == FALSE) {
$this->load->view('login');
} else {
$data = array(
'username' => $this->input->post('username'),
'password' => $this->input->post('password')
);
$result = $this->User_model->login($data);
if($result == TRUE){
$sess_array = array(
'username' => $this->input->post('username')
);

// Add user data in session
$this->session->set_userdata('logged_in', $sess_array);
$result = $this->User_model->read_user_information($sess_array);
if($result != false){
$data = array(
'name' =>$result[0]->name,
'username' =>$result[0]->name,
'email' =>$result[0]->email,
'password' =>$result[0]->psw
);
$this->session->set_userdata('logged_in', $sess_array);
$obj=$this->User_model->show_user();
$pagedata['fetch_list']=$obj; 
$this->load->view("show",$pagedata);
$this->load->view('login_w.php',$sess_array);
//add new
//add new 
//redirect('http://localhost/ci/index.php/Users/list');
}
}else{
$data = array(
'error_message' => 'Invalid Username or Password'
);
$this->load->view('login', $data);
}
}

/*
 $this->load->view('login');

    if (isset($_POST['login'])) 
    {

     $emailid = $this->input->post('username');
     $password = $this->input->post('password');

        $this->load->model('main_model');

        if($this->User_model->login('$emailid','$Password'))
        {   

            $session_data = array(
                 'email' => $emailid,
                 'password' => $password,
                 'iss_logged_in' => 1
            );
            $this->session->set_userdata($session_data);
             redirect(base_url().'index.php/Hello_cnt/');

        }
        else
        {
             $this->session->set_flashdata('error', 'Invalid Username and Password');
           redirect(base_url().'index.php/Hello_cnt/login');

        }
    }   

*/


}

function list()
{
$obj=$this->User_model->show_user();
$pagedata['fetch_list']=$obj; 
$this->load->view("show",$pagedata);
}
function update($id)
{
  			$obj=$this->User_model->show($id);
  			$fetch_d['user']=$obj;


$this->load->view("update",$fetch_d);


	        // get the first row

	
	/*$query=$this->db->query("SELECT * FROM tbl_admin WHERE id='$id'");
		return $query;*/
		
	

}

	function delete($id)
	{
		$run = $this->User_model->delete_user($id);
		/*if($run)
		{
			$msg="<div class='alert alert-success'>Console has been Delete Successfully</div>";
		}
		else
		{
			$msg="<div class='alert alert-danger'>Please try again!</div>";
		}*/
		$msg="<div class='alert alert-success'>User has been Delete Successfully</div>";
		$this->session->set_flashdata("msg",$msg);
		redirect("Users/list");
	}
	
	public function logout() {

// Removing session data
$sess_array = array(
'username' => ''
);
$this->session->unset_userdata('logged_in', $sess_array);
$data['message_display'] = 'Successfully Logout';
$this->load->view('login', $data);
}

/* add new*/

public function profile_update()
	{

		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		$this->form_validation->set_rules('ads', 'Email', 'required');
		$this->form_validation->set_rules('phone', 'Phone', 'required');


		if ($this->form_validation->run() == false)
		{
			//$errors = validation_errors();

		/*$msg="<div class='alert alert-danger'>" .validation_errors()
. "</div>";
     	$this->session->set_flashdata("msg",$msg);*/

		}else{
			//$id=$this->session->userdata('id');
			 $id=$this->input->post("hid");
						$name=$this->input->post("name");
			$email=$this->input->post("email");
					$ads=$this->input->post("ads");
					$phone=$this->input->post("phone");

			$data['name']=$name;
			$data['email']=$email;
			$data['phone']=$phone;
			$data['address']=$ads;

/* add new */

                   $config['upload_path']="img";
			$config['allowed_types'] = '*';
			$config['encrypt_name']=true;
			$this->load->library("upload",$config);

         
	        $this->upload->do_upload('image');

	        $data['image']=$this->upload->data("file_name");

/* add new*/


			$obj=$this->User_model->update_p($id,$data);
			//$this->load->view("update.php");
			redirect("http://localhost/ci/index.php/Users/Update/".$id);
		}
	}

/*add new*/


function jsde()
	{
				$this->load->view("show");		

		$this->form_validation->set_rules('f', ' Name', 'required');
		$this->form_validation->set_rules('l', 'Last Name', 'required');
		

		if ($this->form_validation->run() == FALSE)
		{
			$json['status'] = 0;
			$json['msg'] = validation_errors();
		}
		else
		{ 

			
			
					
			
			}
			
		echo json_encode($json);	

	}

	function show()
	{
		$this->load->view("show");
	}


}


